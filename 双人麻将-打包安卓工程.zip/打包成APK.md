# 打包成安卓 App（APK）

目标：手机上**下载一个 .apk 安装包**，装完后是桌面图标、全屏横屏运行，
**不是浏览器网页**，断网也能玩。

> 这台电脑上没有 Java / Android SDK（我查过了：`java`、`gradle`、`sdkmanager` 都不存在），
> 所以本地直接编译 APK 做不到。下面三条路任选，都不需要在这台电脑装 Android Studio。

---

## 路线 A：GitHub 自动打包（推荐，一次配置，以后自动出包）

代码已经在 GitHub 上，让 GitHub 的服务器帮你编译，产出 APK 供下载。

### 步骤

1. **替换流水线文件**
   - 打开仓库里的 `.github/workflows/build-apk.yml`
   - 全选删除，把本文件夹的 `build-apk.yml` **整段粘进去** → Commit

   > 新版流水线**不需要**再上传 `mobile/` 目录：安装 Capacitor、生成安卓工程都在云端自动完成。

2. **运行打包**
   - 仓库 → **Actions** → 左侧「打包安卓 APK」→ **Run workflow**

3. **下载 APK**（3～6 分钟，第一次久一点）
   - 运行成功 → 页面底部 **Artifacts** → `双人麻将-APK.zip` → 解压得 `app-debug.apk`
   - 或者去 **Releases** 页面，那里有一份 APK 可直接在手机浏览器点开下载

4. **装到手机**
   - APK 发到手机（数据线 / 网盘 / 微信文件都行）
   - 点开安装，提示「未知来源」时允许一次
   - 桌面出现「双人麻将」图标，点开是**全屏横屏**的游戏

### 这个 APK 的特点

- 游戏文件**打包进安装包**（Capacitor 打包），不是套壳打开网页
- 没有地址栏、没有下载页，启动直接进牌桌
- **断网也能玩**
- 屏幕方向强制横屏（`sensorLandscape`）

### 流水线做了什么

1. 装 Node 20 / Java 17（runner 自带 Android SDK）
2. 把 `index.html`、`css/`、`js/`、图标、manifest、sw 拷进 `mobile/www/`
3. 检测到下载页就把 `showLanding` 改成 `false`（APK 里直接进游戏）
4. `npm i @capacitor/*` → `cap init` → `cap add android` → `cap sync`
5. 把 `AndroidManifest.xml` 的屏幕方向改成 `sensorLandscape`
6. `./gradlew assembleDebug` 出包
7. 上传 Artifact + 发 Release

---

## 路线 B：PWABuilder（5 分钟，完全不用写代码）

如果你连 Actions 都不想碰：

1. 电脑或手机打开 **https://www.pwabuilder.com**
2. 输入你的网址：`https://furryqi.github.io/furryqiqiqi/`
3. 等它检测完（会显示 manifest / service worker 都 ✔）
4. 点 **Package for stores** → 选 **Android** → **Download package**
5. 得到 `*.apk`，按路线 A 第 5 步装到手机

> 这条路线生成的是 TWA（可信网页应用）外壳：图标、全屏、无地址栏都满足，
> 但内容仍来自你的网址，**第一次打开需要联网**（之后有离线缓存）。
> 想要「打包进 APK、彻底离线」，用路线 A。

---

## 路线 C：本机装 Android Studio 自己编译

适合你以后想改安卓端（改图标、改包名、加权限）：

1. 装 **Android Studio**（自带 JDK 和 SDK，约 3 GB）
2. 在本文件夹执行：
   ```bash
   cd mobile
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
3. Android Studio 里：**Build → Build Bundle(s)/APK(s) → Build APK(s)**
4. 产物在 `mobile/android/app/build/outputs/apk/debug/app-debug.apk`

---

## 已经替你配好的东西

| 文件 | 作用 |
|---|---|
| `mobile/package.json` | Capacitor 依赖（core / cli / android 6.x） |
| `mobile/capacitor.config.json` | 应用名「双人麻将」、包名 `com.mahjong.two`、网页目录 `www` |
| `build-apk.yml` | GitHub Actions 全流程：装环境 → 拷游戏 → 生成安卓工程 → **强制横屏** → 编译 → 上传 APK + 发 Release |

打包脚本里已经做了这些处理：

- 把 `index.html`、`css/`、`js/`、图标、manifest、sw 拷进 `www/`
- 若根目录找不到 `index.html`，自动退回用 `双人麻将-单文件版.html`
- 把 `AndroidManifest.xml` 的屏幕方向改成 **sensorLandscape（横屏）**
- 产出 `app-debug.apk`（调试签名，可直接安装，不需要证书）

---

## 安装时常见问题

**手机提示「已阻止安装」？**
设置 → 应用 → 特殊权限/未知来源 → 允许「文件管理」或「浏览器」安装应用。

**提示「解析包出错」？**
APK 没下载完整（常见于微信内下载），改用手机浏览器重新下载一次。

**装完打开是竖屏？**
脚本里已改为横屏；如果仍竖屏，检查手机的「自动旋转」是否打开。

**能升级覆盖安装吗？**
可以，只要包名不变（`com.mahjong.two`），新 APK 直接覆盖安装，存档（设置项）会保留。

---

## 想改图标 / 名字 / 包名

- 名字：改 `mobile/capacitor.config.json` 里的 `appName`
- 包名：改 `appId`（改了之后要重新装，不能覆盖旧版）
- 图标：替换 `mobile/android/app/src/main/res/mipmap-*/ic_launcher.png`（首次 `cap add android` 之后才有这些目录）；
  简单做法是在 `mobile/www/` 放 `icon-512.png`，再用图标生成工具替换。
