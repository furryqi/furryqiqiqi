/* ============================================================================
 *  双人麻将 · 界面逻辑  ui.js
 * ==========================================================================*/
(function () {
  'use strict';
  const E = window.MJEngine;
  const G = window.MJGame;
  const A = window.MJAI;
  const HUMAN = 0, AI = 1;

  const $ = (id) => document.getElementById(id);

  const game = new G.Game({
    onChange: () => { render(); scheduleAI(); },
  });

  const AI_DELAY = 2000;       // 电脑每步固定 2 秒
  let aiTimer = null;
  let busy = false;
  let resultShown = false;
let gameEnded = false;      // 提前结束（或已打满）后：牌桌只可查看，不再继续
  let riichiPick = null;       // 进入「选宣言牌」状态时存放可打的牌
  let tianhuRound = -1;        // 哪一局走了「天胡延迟」
  let tianhuDeadline = 0;      // 延迟结束时间戳

  /* ------------------------------------------------------------ 定时驱动 AI */
  function scheduleAI() {
    clearTimeout(aiTimer);
    const st = game.state;
    if (!st || st.result) return;
    if (game.opts.testMode) {
      // 测试模式：AI 不动，但自己报听后要继续自动摸切，直到胡牌或摸完牌墙
      const autoRiichi = st.phase === 'discard' && st.turn === HUMAN &&
        st.players[HUMAN].riichi && !st.selfWin && st.drawn != null;
      if (autoRiichi) aiTimer = setTimeout(aiStep, AI_DELAY);
      return;
    }
    const needAI = (st.phase === 'claim' && st.claim && st.claim.player === AI) ||
      (st.phase === 'discard' && st.turn === AI) ||
      (st.phase === 'discard' && st.turn === HUMAN && st.players[HUMAN].riichi && !st.selfWin && st.drawn != null);
    if (!needAI) return;
    aiTimer = setTimeout(aiStep, AI_DELAY);   // 电脑出牌/鸣牌的固定思考时间
  }

  function aiStep() {
    const st = game.state;
    if (!st || st.result || busy) return;
    // 发牌/理牌动画还没播完，先不要动（否则动画中途手牌会变，看起来像重播一遍）
    if (dealAnim) { scheduleAI(); return; }
    busy = true;
    try {
      if (st.phase === 'claim' && st.claim && st.claim.player === AI) {
        const d = A.decideClaim(game);
        if (!game.claim(d.action, d.chiPair)) game.claim('pass');
        return;
      }
      if (st.phase === 'discard' && st.turn === AI) {
        // 摸到能自摸的牌（含癞子万能）必胡：这里再兜底算一次，防止 selfWin 没刷新
        const aiWin = st.selfWin || game.checkWin(AI, null, { tsumo: true });
        if (aiWin) {
          st.selfWin = aiWin;
          game.declareSelfWin(AI);
          return;
        }
        const k = A.decideSelfKan(game, AI);
        if (k && game.selfKan(AI, k.type, k.tile)) return;
        if (A.maybeRiichi(game, AI)) return;   // 已经宣言报听并打出宣言牌
        const idx = A.decideDiscard(game, AI);
        game.discard(AI, idx);
        return;
      }
      if (st.phase === 'discard' && st.turn === HUMAN && st.players[HUMAN].riichi) {
        // 报听后自动摸切；但只要能自摸（包括摸到癞子）就先胡
        const win = st.selfWin || game.checkWin(HUMAN, null, {});
        if (win) {
          st.selfWin = win;
          game.declareSelfWin(HUMAN);
          return;
        }
        const p = st.players[HUMAN];
        const i = p.hand.indexOf(st.drawn);
        if (i >= 0) game.discard(HUMAN, i);
      }
    } finally {
      busy = false;
    }
  }

  /* ------------------------------------------------------------ 牌面渲染 */
  // 牌面：万字=上数字下「萬」，字牌=单字，白板=空框，花牌=圆章
  // 手牌展示排序：癞子放最左边，其余从小到大
  function wildFirst(t) { return t === E.WILD ? -1 : t; }
  function sortedTiles(arr) { return arr.slice().sort((a, b) => wildFirst(a) - wildFirst(b)); }
  function sortedObjs(arr) { return arr.slice().sort((a, b) => wildFirst(a.t) - wildFirst(b.t)); }

  // 分数 / 番数显示：无穷大显示成 ∞
  function fmtScore(n) {
    return (typeof n === 'number' && !isFinite(n)) ? '∞' : n;
  }
  function fmtFan(n) {
    return (typeof n === 'number' && !isFinite(n)) ? '∞' : n;
  }

  function tileEl(t, cls) {
    const d = document.createElement('div');
    d.className = 'tile' + (cls ? ' ' + cls : '');
    if (t === E.WILD) {
      d.classList.add('joker');
      d.innerHTML = '<span class="jz">癞</span><span class="wtag">万能</span>';
    } else if (t < 9) {
      d.innerHTML = '<span class="rank">' + E.CN_NUM[t] + '</span><span class="suit">萬</span>';
    } else if (t < 16) {
      const idx = t - 9;
      d.classList.add('h' + idx);
      if (idx !== 6) d.innerHTML = '<span class="honor">' + E.CN_HONOR[idx] + '</span>';
    } else {
      d.classList.add('flower', t - 16 < 4 ? 'season' : 'plant');
      d.innerHTML = '<span class="fl">' + E.CN_FLOWER[t - 16] + '</span>';
    }
    return d;
  }

  // 副露里的「背面牌」：尺寸跟随所在容器（--tw/--th 或 .back 默认）
  function backEl(cls) {
    const b = document.createElement('div');
    b.className = 'back' + (cls ? ' ' + cls : '');
    return b;
  }

  function meldEl(m, size, reveal) {
    const cls = size === true ? 'small' : (typeof size === 'string' ? size : '');
    const box = document.createElement('div');
    box.className = 'meld' + (m.kind === 'ankan' ? ' concealed' : '');
    if (m.kind === 'ankan' && !reveal) {
      // 暗杠：外侧两张亮出、中间两张背面（和结算面板一致）
      box.appendChild(tileEl(m.tiles[0], cls));
      box.appendChild(backEl(cls));
      box.appendChild(backEl(cls));
      box.appendChild(tileEl(m.tiles[0], cls));
      return box;
    }
    m.tiles.forEach((t) => box.appendChild(tileEl(t, cls)));
    return box;
  }

  let lastDropKey = null;
  // 开局发牌动画：4 张 4 张地进场，结束后排序
  let dealAnim = null;        // { round, n, shown, order, phase }
  // 开局花牌进场：0=正在发牌（花牌区空）1=花牌摆在手牌最右 2=飘向花牌区
  let flowerIntro = null;
  let pendingFillTiles = [];       // 补花补进来的牌（落位时播一次下落动画）

  function introFlowers() {
    const st = game.state;
    if (!st || !st.players || !st.players[HUMAN]) return [];
    return (st.players[HUMAN].flowers || []).slice();
  }
  function introTrimCount() {
    if (!flowerIntro) return 0;
    return introFlowers().length;      // 只影响自己的手牌（电脑是背面）
  }
  function introStage() { return flowerIntro ? flowerIntro.stage : -1; }
  // 发牌结束 → 花牌停在最右 → 飞进花牌区 → 补牌先落在花牌原位 → 理牌
  function beginFlowerFly() {
    if (!flowerIntro || flowerIntro.stage !== 0) return;
    flowerIntro = { stage: 1 };          // 理好牌，花牌留在最右边
    flowerSeen[HUMAN] = 0;
    render();
    const flowers = introFlowers();
    setTimeout(() => {
      if (!flowerIntro) return;
      flowerIntro = { stage: 2 };        // 花牌落进花牌区，同时补牌出现在摸牌位
      render();
      flowers.forEach((t, i) => setTimeout(() => { flyFlower(HUMAN, t, () => {}); }, i * 110));
      setTimeout(() => {
        if (!flowerIntro) return;
        const cutTiles = (flowerIntro && flowerIntro.cut) ? flowerIntro.cut.slice() : [];
        flowerIntro = null;              // 理牌：补牌直接落到各自的位置
        pendingFillTiles = cutTiles;     // 这几张落位时播下落动画
        render();                        // 先让补牌落位
        setTimeout(() => {               // 落位完成后再摸第一张
          if (game.firstDraw) game.firstDraw();
          render();
          scheduleAI();
        }, 360);
      }, 500);
    }, 500);
  }
  let lastDealRound = -1;
  function beginDeal(st) {
    if (!document.body || !document.createElement) return;   // 无 DOM（测试环境）直接跳过
    const hand = st.players[HUMAN].hand;
    const n = hand.length;
    if (n < 4) return;
    // 庄家 14 张时，最后摸进来的那张不参与理牌
    let extra = -1;
    if (n % 3 === 2 && st.drawn != null) {
      for (let i = n - 1; i >= 0; i--) if (hand[i] === st.drawn) { extra = i; break; }
    }
    const order = hand.map((t, i) => i).filter((i) => i !== extra);
    for (let i = order.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      const tmp = order[i]; order[i] = order[j]; order[j] = tmp;
    }
    dealAnim = {
      round: st.seq != null ? st.seq : st.roundNo, n: order.length,
      shown: 0, order: order, extra: extra, phase: 'dealing',
    };
    const tick = () => {
      if (!dealAnim || dealAnim.round !== (st.seq != null ? st.seq : st.roundNo)) return;
      dealAnim.shown = Math.min(dealAnim.n, dealAnim.shown + 3);
      if (dealAnim.shown >= dealAnim.n) {
        // 13 张到手 -> 水平平移到各自排序后的位置
        dealAnim.phase = 'sliding';
        render();
        setTimeout(() => {
          if (!dealAnim) return;
          if (dealAnim.extra >= 0) {
            dealAnim.phase = 'extra';        // 理完牌，最后一张落下
            render();
            setTimeout(() => { if (dealAnim) { dealAnim = null; render(); beginFlowerFly(); } }, 420);
          } else {
            dealAnim = null;
            render();
            beginFlowerFly();
          }
        }, 1300);
        return;
      }
      render();
      setTimeout(tick, 300);        // 每批之间的间隔（放慢）
    };
    setTimeout(tick, 220);          // 第一批的等待
  }
  function dealingNow() { return !!dealAnim; }

  function fillHand(el, p, isHuman) {
    el.innerHTML = '';
    const st = game.state;
    if (!isHuman) {
      // 开局发牌动画中：对手一点点亮出牌背（测试模式没有对手，不放动画）
      if (dealAnim && dealAnim.phase === 'dealing') {
        if (game.opts.testMode) { el.innerHTML = ''; return; }
        const shown = Math.min(dealAnim.shown, 13);
        for (let k = 0; k < shown; k++) {
          const b = document.createElement('div');
          b.className = 'back';
          el.appendChild(b);
        }
        return;
      }
      // 透视模式；报听亮牌默认关闭，需要在设置里勾选「报听看牌」
      const riichiReveal = game.opts.revealOnRiichi === true &&
        game.state.players[HUMAN] && game.state.players[HUMAN].riichi;
      // 只有「查看牌桌」（结算面板收起、且已经弹过结算）时才亮牌；胡牌那一刻仍然盖着
      const overReveal = gameEnded ||
        !!(game.state.result && resultShown && $('modal') && $('modal').hidden);
      // 电脑摸牌 / 电脑胡牌时，那张牌单独放在摸牌位
      const aiWon = !!st.result && st.result.winner === AI;
      const oppDrawn = st.drawn != null && (st.result ? aiWon : st.turn === AI);
      if (game.opts.peekMode || riichiReveal || overReveal) {
        const list = sortedTiles(p.hand);
        if (oppDrawn) {
          for (let k = list.length - 1; k >= 0; k--) {
            if (list[k] === st.drawn) { list.push(list.splice(k, 1)[0]); break; }
          }
        }
        list.forEach((t, k) => {
          const cls = 'peek' + (oppDrawn && k === list.length - 1 ? ' drawn' : '');
          el.appendChild(tileEl(t, cls));
        });
        return;
      }
      const n = p.hand.length;
      for (let i = 0; i < n; i++) {
        const b = document.createElement('div');
        // 电脑摸牌时，摸到的那张和原有手牌隔开一点
        b.className = 'back' + (oppDrawn && i === n - 1 ? ' drawn' : '');
        el.appendChild(b);
      }
      return;
    }
    // 排序阶段：每张牌从「发牌时的位置」水平滑到「排序后的位置」
    if (dealAnim && dealAnim.phase === 'sliding') {
      const slotOf = {};
      dealAnim.order.forEach((idx, k) => { slotOf[idx] = k; });
      const list = sortedObjs(dealAnim.order.map((i) => ({ t: p.hand[i], i: i })));
      const STEP = 56;                        // 牌宽 54 + 间距 2
      list.forEach((o, d) => {
        const el2 = tileEl(o.t, 'slidein');
        el2.style.setProperty('--dx', ((slotOf[o.i] - d) * STEP) + 'px');
        el2.style.zIndex = String(30 - Math.abs(slotOf[o.i] - d));
        el.appendChild(el2);
      });
      return;
    }

    // 理牌结束：最后一张（庄家摸的）才落下
    if (dealAnim && dealAnim.phase === 'extra') {
      const list = sortedObjs(dealAnim.order.map((i) => ({ t: p.hand[i], i: i })));
      list.forEach((o) => el.appendChild(tileEl(o.t, '')));
      if (dealAnim.extra >= 0) {
        el.appendChild(tileEl(p.hand[dealAnim.extra], 'drop drawn'));
        // 记下这次已经播过落牌动画，下一次正常渲染不要重播
        const dcount = st.players.reduce((a, q) => a + q.discards.length, 0);
        lastDropKey = st.round + '|' + st.turn + '|' + dcount + '|' + p.hand.length + '|' + st.drawn;
      }
      return;
    }

    // 开局发牌动画中：只显示到手的牌（未排序）
    if (dealAnim && dealAnim.phase === 'dealing') {
      const shown = dealAnim.shown;
      const from = Math.max(0, shown - 3);          // 只有最新落下的 3 张做落牌动画
      // 花牌当成普通牌一起发下来：先发手牌，最后几张是花牌
      const trimN = introTrimCount();
      let dealSeq = dealAnim.order.slice();
      if (trimN > 0) {
        dealSeq = dealSeq.slice(0, dealAnim.order.length - trimN).map((i) => p.hand[i]);
        // 花牌混在发牌序列里（按发牌顺序随机插入），之后理牌时再摆到最右边
        introFlowers().slice(0, trimN).forEach((ft) => {
          const at = 4 + Math.floor(Math.random() * Math.max(1, dealSeq.length - 6));
          dealSeq.splice(Math.min(at, dealSeq.length), 0, ft);
        });
      } else {
        dealSeq = dealSeq.map((i) => p.hand[i]);
      }
      const capDeal = Math.min(shown, dealSeq.length);
      dealSeq.slice(0, capDeal).forEach((t, k) => {
        if (t != null) el.appendChild(tileEl(t, k >= Math.max(0, capDeal - 3) ? 'drop' : ''));
      });
      return;
    }

    const riichiLocked = !!(p.riichi || st.players[HUMAN].riichi);
    // 报听中手牌锁定；但如果摸到了能胡的牌，允许把这张打出去（见逃）
    const canDiscard = !gameEnded && st.phase === 'discard' && st.turn === HUMAN && !st.claim &&
      !st.result && !dealingNow() && (!riichiLocked || !!st.selfWin);

    const order = sortedObjs(p.hand.map((t, i) => ({ t: t, i: i })));
    // 轮到自己在打牌时就显示摸牌位；一局结束时，只有自己胡了才显示（那张就是胡的牌）
    const humanWon = !!st.result && st.result.winner === HUMAN;
    // 手里还有花牌时先不显示摸进来的那张：等花牌全部进区后才「摸第一张」
    const flowersInHand = !!flowerIntro && introFlowers().length > 0;
    const drawnShown = !flowersInHand && st.drawn != null &&
      (st.result ? humanWon : st.turn === HUMAN);
    if (drawnShown) {
      let di = -1;
      for (let k = order.length - 1; k >= 0; k--) if (order[k].t === st.drawn) { di = k; break; }
      if (di >= 0) { const x = order.splice(di, 1)[0]; order.push(x); }
    }
    // 开局花牌进场：手牌末尾留出 N 个位置
    // 阶段 1/2 → 花牌占着；阶段 3 → 补摸的牌占着（随后理牌）
    const trimN = introTrimCount();
    const stage = introStage();
    let ghostTiles = [];
    if (trimN > 0) {
      const keep = order.length - (drawnShown ? 1 : 0);
      const startAt = Math.max(0, keep - trimN);
      const cut = order.splice(startAt, trimN);
      if (stage <= 1) {
        ghostTiles = introFlowers().slice(0, trimN);   // 花牌全在最右边
      } else if (flowerIntro) {
        flowerIntro.cut = cut.map((o) => o.t);         // 记下补进来的牌
      }
      // 阶段 2：花牌已拿走，先空着；结束后补牌直接出现在各自位置
    }

    // 补花补进来的那几张：这次渲染加下落动画
    const fillLeft = (pendingFillTiles || []).slice();
    order.forEach((o, k) => {
      const isDrawn = drawnShown && k === order.length - 1 && o.t === st.drawn;
      let extra = '';
      let pickable = false;
      if (riichiPick) {
        pickable = riichiPick.some((x) => x.tile === o.t);
        const info = riichiPick.find((x) => x.tile === o.t);
        extra = pickable ? (' pick' + (info && info.best ? ' pick-best' : '')) : ' dim';
      }
      // 报听后手牌压暗；但刚摸到的那张保持正常亮度，能胡 / 一局结束时整手牌也恢复亮度
      const locked = (st.players[HUMAN].riichi || p.riichi) && !st.selfWin && !st.result;
      // 只有「真的刚摸到」才播放下落动画（同一张牌不重复播）
      let drop = false;
      if (isDrawn) {
        const st2 = game.state;
        const dcount = st2.players.reduce((a, q) => a + q.discards.length, 0);
        const key = st2.round + '|' + st2.turn + '|' + dcount + '|' + p.hand.length + '|' + st2.drawn;
        if (key !== lastDropKey) { lastDropKey = key; drop = true; }
      }
      // 报听锁定后只有刚摸的那张可以点（胡了也可以选择打出去）
      const clickable = canDiscard && (!riichiLocked || isDrawn);
      const cls = ((isDrawn ? ' drawn' : '') + (drop ? ' drop' : '') + (clickable ? '' : ' disabled') +
        (locked && !isDrawn ? ' riichi-dim' : '') + extra).trim();
      let cls2 = cls;
      const fi = fillLeft.indexOf(o.t);
      if (fi >= 0) { fillLeft.splice(fi, 1); cls2 = (cls2 + ' fill-drop').trim(); }
      const el2 = tileEl(o.t, cls2);
      if (clickable) {
        if (riichiPick && !pickable) {
          el2.addEventListener('click', () => { riichiPick = null; render(); });   // 点暗牌取消
        } else if (riichiPick && pickable) {
          el2.addEventListener('click', () => {
            if (busy) return;
            const idx = o.i;
            riichiPick = null;
            hideTilePreview();
            game.riichi(HUMAN, idx);
          });
          el2.addEventListener('mouseenter', () => showTilePreview(el2, o));
          el2.addEventListener('mouseleave', hideTilePreview);
          el2.addEventListener('touchstart', () => showTilePreview(el2, o), { passive: true });
        } else {
          el2.addEventListener('click', () => {
            if (busy) return;
            game.discard(HUMAN, o.i);
          });
        }
      }
      el.appendChild(el2);
    });
    // 末尾占位：花牌 or 刚落下的补牌
    ghostTiles.forEach((t, gi) => {
      const isFlower = stage <= 1;
      const g = tileEl(t, (isFlower ? 'flower-stand' : 'drop') +
        (gi > 0 ? ' concat-gap' : ' spaced-tail'));
      g.classList.add('disabled');
      // 花牌摆在「摸牌位之前」：摸进来的那张始终占最右边
      const last = el.lastElementChild;
      if (drawnShown && last && last.classList.contains('drawn')) {
        el.insertBefore(g, last);
      } else {
        el.appendChild(g);
      }
    });
  }

  /* ------------------------------------------------- 听牌候选：番数×剩余张数 */
  // 已现的牌（牌河 + 副露 + 自己手牌）
  function seenCounts() {
    const st = game.state;
    const seen = {};
    st.players.forEach((q) => {
      (q.discards || []).forEach((t) => { seen[t] = (seen[t] || 0) + 1; });
      (q.jokerDiscards || []).forEach((t) => { seen[t] = (seen[t] || 0) + 1; });
      (q.melds || []).forEach((m) => m.tiles.forEach((t) => { seen[t] = (seen[t] || 0) + 1; }));
    });
    st.players[HUMAN].hand.forEach((t) => { if (t < 16) seen[t] = (seen[t] || 0) + 1; });
    return seen;
  }

  function buildRiichiPick() {
    const st = game.state;
    const p = st.players[HUMAN];
    const seen = seenCounts();
    // 现在报听算不算天听（预览时也要把 12 番算进去，否则和实际胡牌对不上）
    const tipTianting = (game.wouldBeTianting && game.wouldBeTianting(HUMAN)) === true;
    const opts = game.riichiOptions(HUMAN).map((o) => {
      const rest = p.hand.slice();
      rest.splice(rest.indexOf(o.tile), 1);
      const waits = E.waits(rest, p.melds);
      let score = 0;
      const detail = waits.map((w) => {
        // 报听预览：默认按点炮算，癞子 / 点炮不够番时按自摸算并注明
        const d = previewFan(rest, w, { baoting: true, tianting: tipTianting });
        const left = Math.max(0, 4 - (seen[w] || 0));
        if (d.ok) score += d.fan * left;
        return { tile: w, fan: d.fan, left: left, ok: d.ok, note: d.note, infinite: d.infinite };
      });

      // 癞子当胡牌张：只要听得见，摸到癞子也能胡（牌墙里还有癞子才算）
      if (waits.length) {
        const wildTotal = game.opts.jokerCount == null ? 4 : game.opts.jokerCount;
        const wildLeft = Math.max(0, wildTotal - (seen[E.WILD] || 0));
        if (wildLeft > 0) {
          // 癞子在手里/当和牌张都只能自摸
          const dw = previewFan(rest, E.WILD, { baoting: true, tianting: tipTianting });
          if (dw.ok) score += dw.fan * wildLeft;
          detail.push({ tile: E.WILD, fan: dw.fan, left: wildLeft, ok: dw.ok, note: dw.note, infinite: dw.infinite });
        }
      }
      return { tile: o.tile, score: score, detail: detail };
    });
    let best = -1;
    opts.forEach((o) => { if (o.score > best) best = o.score; });
    opts.forEach((o) => { o.best = o.score === best && best > 0; });
    return opts;
  }

  /* ------------------------------------------------- 听牌选牌时的悬停预览 */
  let previewEl = null;
  function hideTilePreview() {
    if (previewEl && previewEl.parentNode) previewEl.parentNode.removeChild(previewEl);
    previewEl = null;
  }

  // 当前这一局的唯一标识（换局后浮动窗自动失效）
  function roundKey() {
    const st = game.state;
    if (!st) return '';
    return (st.seq != null ? st.seq : 0) + ':' + (st.roundNo || 0);
  }

  function showTilePreview(anchor, o) {
    hideTilePreview();
    const tipKey = roundKey();
    const info = (riichiPick || []).find((x) => x.tile === o.t);
    if (!info) return;

    const box = document.createElement('div');
    box.className = 'tileprev';

    // 只保留「牌 / 剩余张数 / 番数」三列；不够起胡番的番数标红
    info.detail.forEach((d) => {
      const row = document.createElement('div');
      row.className = 'tp-row';
      row.innerHTML = '<span class="tp-tile">' + E.tileLabel(d.tile) + '</span>' +
        '<span class="tp-left">剩 ' + d.left + ' 张</span>' +
        '<span class="tp-fan' + (d.note ? ' only-tsumo' : (d.ok ? '' : ' low')) + '">' +
        (d.infinite ? '∞' : d.fan) + ' 番</span>';
      box.appendChild(row);
    });

    document.body.appendChild(box);
    const r = anchor.getBoundingClientRect();
    const bw = box.getBoundingClientRect().width;
    let left = r.left + r.width / 2 - bw / 2;
    left = Math.max(8, Math.min(window.innerWidth - bw - 8, left));
    const top = Math.max(8, r.top - box.getBoundingClientRect().height - 10);
    box.style.left = left + 'px';
    box.style.top = top + 'px';
    previewEl = box;
    box.__rk = tipKey;
  }

  /* -------------------------------------------------- 花牌区 & 补花动画 */
  let flowerAnimating = false;
  let flowerRoundNo = -1;
  const flowerSeen = [0, 0];

  function flowerEl(pi) { return pi === 0 ? $('flowersMe') : $('flowersOpp'); }

  function fillFlowers(pi) {
    const arr = (flowerIntro && flowerIntro.stage <= 1)
      ? []                                   // 花牌还停在手上
      : (game.state.players[pi].flowers || []);
    const el = flowerEl(pi);
    if (!arr.length) el.classList.remove('showing');
    el.innerHTML = '';
    for (let i = 0; i < arr.length; i++) {
      const t = tileEl(arr[i], 'small' + (i >= flowerSeen[pi] ? ' land' : ''));
      el.appendChild(t);
    }
    flowerSeen[pi] = arr.length;
  }

  // 引擎摸到花牌会停在 phase === 'flower'；这里播完动画再让它继续摸下一张，
  // 所以连摸两张花牌时，第一张落进花牌区之后才会出现第二张。
  function maybeFlowerAnim() {
    const st = game.state;
    if (!st || st.phase !== 'flower' || !st.pendingFlower || flowerAnimating) return;
    const f = st.pendingFlower;
    flowerAnimating = true;
    flyFlower(f.player, f.tile, () => {
      flowerAnimating = false;
      game.resolveFlower();
    });
  }

  // 花牌先在摸牌位置停一下，再飘进花牌区
  function flyFlower(pi, tile, done) {
    const anchorEl = pi === 0 ? $('handMe') : $('handOpp');
    const targetEl = flowerEl(pi);
    if (!anchorEl || !targetEl || !document.body ||
        typeof anchorEl.getBoundingClientRect !== 'function' ||
        typeof targetEl.getBoundingClientRect !== 'function') {
      done();
      return;
    }
    // 以「手里最后一张牌」为准，定位真正的摸牌位（容器可能被换行拉高）
    const kids = anchorEl.children;
    const lastTile = kids && kids.length ? kids[kids.length - 1] : null;
    const ar = (lastTile && typeof lastTile.getBoundingClientRect === 'function')
      ? lastTile.getBoundingClientRect()
      : anchorEl.getBoundingClientRect();
    const b = targetEl.getBoundingClientRect();
    const ghost = tileEl(tile, 'small ghost');
    const x = ar.right + 3;
    const y = ar.top - 22;
    ghost.style.left = x + 'px';
    ghost.style.top = y + 'px';
    document.body.appendChild(ghost);

    const HOLD = 1000;      // 摸到花牌：先在摸牌位停 1 秒
    const FLY = 200;        // 然后快速闪进花牌区
    setTimeout(() => {
      const tx = (b.left + b.width / 2) - (x + 17);
      const ty = (b.top + b.height / 2) - (y + 23);
      ghost.style.transform = 'translate(' + tx + 'px,' + ty + 'px) scale(.9)';
      ghost.style.opacity = '.92';
      setTimeout(() => {
        ghost.remove();
        done();
      }, FLY);
    }, HOLD);
  }

  function fillMelds(el, p, reveal) {
    el.innerHTML = '';
    p.melds.forEach((m) => el.appendChild(meldEl(m, true, reveal)));
  }

  // 听牌提示：13 张时算出在等哪些牌，并标出剩余张数
  function renderWaits() {
    const box = $('waitsMe');
    const st = game.state;
    if (!box) return;
    const p = st.players[HUMAN];
    const need = 4 - p.melds.length;
    const hand = p.hand.slice();
    if (st.result || st.phase === 'flower') {
      box.hidden = true;
      box.innerHTML = '';
      hideTilePreview();          // 结算 / 补花时关掉浮动的听牌窗
      return;
    }
    // 13 张（等牌中）直接用；14 张（自己回合）按「打掉摸到的那张」后的手牌算
    let probe = hand;
    if (hand.length === 3 * need + 2) {
      probe = hand.slice();
      const di = st.drawn != null ? probe.lastIndexOf(st.drawn) : -1;
      if (di >= 0) probe.splice(di, 1); else probe.pop();
    } else if (hand.length !== 3 * need + 1) {
      box.hidden = true;
      box.innerHTML = '';
      hideTilePreview();
      return;
    }
    const w = E.waits(probe, p.melds);
    if (!w.length) {
      box.hidden = true;
      box.innerHTML = '';
      hideTilePreview();          // 不再听牌就关掉
      return;
    }
    // 计算每张牌还剩几张（扣除牌河、副露、自己的手牌）
    const seen = {};
    for (let i = 0; i < 16; i++) seen[i] = 0;
    st.players.forEach((q) => {
      q.discards.forEach((t) => { seen[t] = (seen[t] || 0) + 1; });
      (q.jokerDiscards || []).forEach((t) => { seen[t] = (seen[t] || 0) + 1; });
      (q.melds || []).forEach((m) => m.tiles.forEach((t) => { seen[t] = (seen[t] || 0) + 1; }));
    });
    hand.forEach((t) => { if (t < 16) seen[t] = (seen[t] || 0) + 1; });

    box.hidden = false;
    box.innerHTML = '';
    // 右侧一个感叹号标记，鼠标移上去才显示在等哪些牌
    const mark = document.createElement('span');
    mark.className = 'waitmark';
    mark.textContent = '!';
    box.appendChild(mark);
    mark.addEventListener('mouseenter', () => showWaitsTip(mark, w, seen, probe));
    mark.addEventListener('mouseleave', () => {
      if (!mark.dataset.pinned) hideTilePreview();
    });
    // 触屏：点一下固定显示 / 再点关闭
    mark.addEventListener('click', (ev) => {
      ev.stopPropagation();
      if (mark.dataset.pinned) {
        delete mark.dataset.pinned;
        hideTilePreview();
        return;
      }
      mark.dataset.pinned = '1';
      showWaitsTip(mark, w, seen, probe);
    });
  }

  // 用一副 13 张的假设手牌预测（不改变真实手牌）
  function previewWithHand(hand13, tile, asTsumo, extraFlags) {
    const p = game.state.players[HUMAN];
    const saved = p.hand;
    p.hand = hand13.slice();
    try {
      return game.previewWin ? game.previewWin(HUMAN, tile, asTsumo, extraFlags) : null;
    } finally {
      p.hand = saved;
    }
  }

  // 预测番数的显示规则：
  //   1. 自摸与点炮不同 → 只写点炮番数
  //   2. 手里有癞子（只能自摸）→ 写自摸番数，注明「只能自摸」
  //   3. 点炮不够起胡、自摸够 → 写自摸番数，注明「只能自摸」
  function previewFan(hand13, tile, extraFlags) {
    // 只有「和牌张本身是癞子」才只能自摸（别人打出的癞子不能点炮）；
    // 手里有癞子照样可以点炮胡普通牌
    const wild = tile === E.WILD;
    const ron = previewWithHand(hand13, tile, false, extraFlags);
    const tsu = previewWithHand(hand13, tile, true, extraFlags);

    const minFan = E.getMinFan();
    function pack(r, note) {
      return {
        fan: r.fan, ok: r.ok, infinite: r.infinite,
        minFan: r.minFan != null ? r.minFan : E.getMinFan(), note: note || '',
      };
    }
    function none() { return { fan: 0, ok: false, note: '', minFan: minFan }; }

    if (wild) {
      // 和牌张是癞子：按自摸算番，但不再标注「（只能自摸）」
      if (tsu && tsu.ok) return pack(tsu, '');
      if (ron) return pack(ron, '');
      if (tsu) return pack(tsu, '');
      return none();
    }

    if (ron && ron.ok) return pack(ron, '');
    if (tsu && tsu.ok) return pack(tsu, '（只能自摸）');
    // 两种都不够：只写点炮番数，不加标注
    if (ron) return pack(ron, '');
    if (tsu) return pack(tsu, '');
    return none();
  }

  // 悬停感叹号：列出在等哪些牌 + 各剩几张
  function showWaitsTip(anchor, waits, seen, probe) {
    hideTilePreview();
    const tipKey = roundKey();
    const st = game.state;
    const p = st.players[HUMAN];
    const box = document.createElement('div');
    box.className = 'tileprev';
    box.__rk = tipKey;
    const base = (probe || p.hand).slice();
    let best = null;                 // 所有等牌里番数最高的那一项
    let bestTsumo = null;            // 同上，但按「自摸」算（癞子只能自摸，取这个）
    waits.forEach((t) => {
      const left = Math.max(0, 4 - (seen[t] || 0));
      const d = previewFan(base, t);
      const ts = previewWithHand(base, t, true);
      if (ts && (!bestTsumo || ts.fan > bestTsumo.fan)) bestTsumo = ts;
      if (!best || d.fan > best.fan) best = d;
      const row = document.createElement('div');
      row.className = 'tp-row';
      row.innerHTML = '<span class="tp-tile">' + E.tileLabel(t) + '</span>' +
        '<span class="tp-left">剩 ' + left + ' 张</span>' +
        '<span class="tp-fan' + (d.note ? ' only-tsumo' : (d.ok ? '' : ' low')) + '">' +
        (d.infinite ? '∞' : d.fan) + ' 番</span>';
      box.appendChild(row);
    });

    // 癞子也能当胡牌张（牌墙里还有癞子才列）
    if (waits.length) {
      const jokerTotal = game.opts.jokerCount == null ? 4 : game.opts.jokerCount;
      let wildSeen = 0;
      st.players.forEach((q) => {
        (q.discards || []).concat(q.jokerDiscards || []).forEach((x) => { if (x === E.WILD) wildSeen++; });
        (q.melds || []).forEach((m) => m.tiles.forEach((x) => { if (x === E.WILD) wildSeen++; }));
      });
      (p.hand || []).forEach((x) => { if (x === E.WILD) wildSeen++; });
      const jokerLeft = Math.max(0, jokerTotal - wildSeen);
      if (jokerLeft > 0) {
        // 癞子当任意一张等牌用，且只能自摸 → 取「各等牌按自摸算」里的最高番
        const d = bestTsumo && bestTsumo.fan > 0
          ? { fan: bestTsumo.fan, ok: bestTsumo.ok, infinite: bestTsumo.infinite, note: '' }
          : previewFan(base, E.WILD);
        const row = document.createElement('div');
        row.className = 'tp-row';
        row.innerHTML = '<span class="tp-tile">' + E.tileLabel(E.WILD) + '</span>' +
          '<span class="tp-left">剩 ' + jokerLeft + ' 张</span>' +
          '<span class="tp-fan' + (d.ok ? '' : ' low') + '">' +
          (d.infinite ? '∞' : d.fan) + ' 番</span>';   // 胡癞子不标注
        box.appendChild(row);
      }
    }
    document.body.appendChild(box);
    const r = anchor.getBoundingClientRect();
    const bw = box.getBoundingClientRect().width;
    let left = r.right - bw;
    left = Math.max(8, Math.min(window.innerWidth - bw - 8, left));
    const top = Math.max(8, r.top - box.getBoundingClientRect().height - 12);
    box.style.left = left + 'px';
    box.style.top = top + 'px';
    previewEl = box;
  }

  // 打出的癞子单独摆在自己的癞子区
  function fillJokerTray(pi) {
    const p = game.state.players[pi];
    const el = pi === 0 ? $('jokerMe') : $('jokerOpp');
    const arr = p.jokerDiscards || [];
    el.hidden = arr.length === 0;
    el.innerHTML = '';
    arr.forEach((t) => el.appendChild(tileEl(t, 'small')));
  }

  function fillRiver(el, p) {
    el.innerHTML = '';
    p.discards.forEach((t, i) => {
      const last = (i === p.discards.length - 1) &&
        game.state.lastDiscard && game.state.lastDiscard.player === (p === game.state.players[1] ? 1 : 0);
      el.appendChild(tileEl(t, 'small' + (last ? ' last' : '')));
    });
  }

  /* ------------------------------------------------------------ 主渲染 */
  let kanTimer = null;
  // 加杠后停顿 0.7 秒再摸牌
  function scheduleKanDraw(st) {
    if (!st || st.pendingKanDraw == null || kanTimer) return;
    kanTimer = setTimeout(() => {
      kanTimer = null;
      if (game.state && game.state.pendingKanDraw != null) game.finishKanDraw();
    }, 700);
  }

  function render() {
    const st = game.state;
    if (!st) return;
    // 上一局点开的听牌窗，换局/结算后不能残留
    if (previewEl && previewEl.__rk !== roundKey()) hideTilePreview();
    scheduleKanDraw(st);
    // 新一局：先播发牌动画（有结算时直接跳过）
    const dealKey = st.seq != null ? st.seq : st.roundNo;
    if (dealKey !== lastDealRound) {
      lastDealRound = dealKey;
      if (!st.result && !game.over) beginDeal(st);
    }
    const sub = $('subInfo');
    if (sub) sub.textContent = '癞子万能 · 花牌补花 · ' + E.getMinFan() + ' 番起胡';
    const me = st.players[HUMAN], opp = st.players[AI];
    if (document.body && document.body.classList) {
      document.body.classList.toggle('test-mode', !!game.opts.testMode);
    }

    // 天胡：先在牌桌停留 3 秒再弹结算（停留期间比分也先不动）
    if (st.result && st.result.flags && st.result.flags.tianhu && !resultShown &&
        tianhuRound !== st.roundNo) {
      tianhuRound = st.roundNo;
      tianhuDeadline = Date.now() + 3000;
      setTimeout(() => render(), 3050);
    }

    // 用 roundSeq 判断「新一局」：重新开始后天数会从 1 重来，单看 roundNo 会漏掉
    const flowerKey = (st.seq != null ? st.seq : st.roundNo);
    if (flowerKey !== flowerRoundNo) {       // 新一局
      flowerRoundNo = flowerKey;
      const myFlowers = (me.flowers || []).length;
      const anyFlowers = myFlowers + (opp.flowers || []).length;
      if (anyFlowers && !game.opts.testMode && document.body) {
        flowerIntro = { stage: 0 };          // 花牌区先空着，等发牌结束再飘过去
        flowerSeen[0] = 0;
        if (!dealAnim) setTimeout(beginFlowerFly, 260);   // 没有发牌动画时也要播
      } else {
        flowerIntro = null;
        flowerSeen[0] = myFlowers;
      }
      flowerSeen[1] = (opp.flowers || []).length;
    }

    const maxR = (game.opts && game.opts.maxRounds) || 8;
    $('roundNo').textContent = '第 ' + st.roundNo + ' / ' + maxR + ' 局';
    $('dealerInfo').textContent = st.dealer === HUMAN ? '你坐庄' : '电脑坐庄';
    $('wallInfo').textContent = '牌墙 ' + st.wall.length + ' 张';
    const streak = (st.mulFlags && st.mulFlags.drawStreak) || 0;
    const si = $('streakInfo');
    si.hidden = streak <= 0;
    if (streak > 0) si.textContent = '连续流局 ' + streak + ' 局 ×' + Math.pow(2, streak);
    checkWallWarn(st);
    checkRiichiToast(st);
    checkMeldBanner(st);

    // 天胡停留的 3 秒里先显示结算前的比分，避免提前剧透
    const inTianhuPause = st.result && st.result.flags && st.result.flags.tianhu &&
      Date.now() < tianhuDeadline && st.result.scoreBefore;
    $('scoreMe').textContent = fmtScore(inTianhuPause ? st.result.scoreBefore[0] : me.score);
    $('scoreOpp').textContent = fmtScore(inTianhuPause ? st.result.scoreBefore[1] : opp.score);
    // 报听徽章已去掉（不再显示「报听」小标签）
    const jm = me.jokersDiscarded || 0, jo = opp.jokersDiscarded || 0;
    $('bonusMe').hidden = jm <= 0;
    if (jm > 0) $('bonusMe').textContent = '癞子 ×' + Math.pow(2, jm);
    $('bonusOpp').hidden = jo <= 0;
    if (jo > 0) $('bonusOpp').textContent = '癞子 ×' + Math.pow(2, jo);

    fillHand($('handMe'), me, true);
    fillHand($('handOpp'), opp, false);
    fillMelds($('meldsMe'), me, gameEnded);     // 结束后暗杠也亮出
    fillMelds($('meldsOpp'), opp, gameEnded ||
      !!(st.result && resultShown && $('modal') && $('modal').hidden));
    fillFlowers(0);
    fillFlowers(1);
    fillRiver($('riverMe'), me);
    fillRiver($('riverOpp'), opp);
    fillJokerTray(HUMAN);
    fillJokerTray(AI);
    renderWaits();

    if ($('hint')) $('hint').innerHTML = '';   // 中间提示全部去掉
    // 中间那行「你 摸牌 / 电脑 打出 X」已去掉，不再渲染
    if ($('lastev')) $('lastev').textContent = '';

    const isOver = !!st.result;
    const oppSeat = document.querySelector('.seat-opp');
    const meSeat = document.querySelector('.seat-me');
    if (oppSeat && meSeat) {
      oppSeat.classList.toggle('active', !isOver && st.turn === AI);
      meSeat.classList.toggle('active', !isOver && st.turn === HUMAN);
    }

    renderActs();
    renderStatus();
    maybeFlowerAnim();
    if (st.result) {
      // 天胡：停留期还没结束就先不弹
      const isTianhu = !!(st.result.flags && st.result.flags.tianhu);
      if (isTianhu && Date.now() < tianhuDeadline) return;
      if (!resultShown) {
        if (resultPending) return;                 // 横幅还在播，等它播完再弹结算
        // 和牌：先在胡牌者那一侧闪一个红色横幅，再弹结算
        if (st.result.type !== 'draw' && huToastRound !== st.roundNo) {
          huToastRound = st.roundNo;
          resultPending = true;
          const win = st.result.winner === HUMAN;
          showWinBanner(win, !!st.result.tsumo);
          setTimeout(() => {
            resultPending = false;
            if (game.state !== st) return;
            if (!resultShown) { resultShown = true; showResult(st.result); }
          }, 820);
          return;
        }
        resultShown = true;
        showResult(st.result);
      }
    } else {
      resultShown = false;
    }
  }

  function hintText() {
    const st = game.state;
    const me = st.players[HUMAN];
    if (st.result) return '';
    if (st.turn !== HUMAN || st.phase !== 'discard') return '';
    if (st.selfWin) {
      return '<b class="warn">可以自摸和牌！</b>';
    }
    if (st.drawn == null) return '';
    // 能成牌型但番数不够时，直接说明原因（摸到癞子常遇到）
    if (me.hand.length === 3 * (4 - me.melds.length) + 2) {
      const r = E.evaluateWin(me.hand, me.melds, {
        winTile: st.drawn, tsumo: true, baoting: me.riichi,
        flowerCount: (me.flowers || []).length,
      });
      const line = r && r.minFan != null ? r.minFan : E.getMinFan();
      if (r && r.fan > 0 && r.fan < line) {
        return '<b class="warn">可以和牌，但番数不足（' + r.fan + ' / ' + line + ' 番）</b>';
      }
    }
    return '';      // 「打出这张后听 xxx」的提示已按需求去掉
  }

  function lastEventText() {
    const st = game.state;
    if (st.result) return '';        // 结算后这行不显示（谁胡了由弹窗/横幅表示）
    const ev = st.lastEvent;
    if (!ev) return '';
    if (ev.type === 'discard') return (ev.player === HUMAN ? '你' : '电脑') + ' 打出 ' + E.tileLabel(ev.tile);
    if (ev.type === 'draw') return (ev.player === HUMAN ? '你' : '电脑') + ' 摸牌';
    return '';
  }

  function renderStatus() {
    const st = game.state;
    // 对局结束后（提前结束或打满局数）「结束对局」按钮就没用了，直接隐藏
    const ended = gameEnded || !!game.over;
    if ($('btnEnd')) $('btnEnd').style.display = ended ? 'none' : '';
    if (ended) { $('status').textContent = '对局已结束'; return; }
    let s = '';
    if (st.result) s = '';
    else if (st.phase === 'claim' && st.claim && st.claim.player === HUMAN) s = '请选择：胡 / 杠 / 碰 / 吃 / 过';
    else if (st.phase === 'flower') s = '补花中…';
    else if (st.phase === 'claim') s = '电脑思考中…';
    else if (st.phase === 'discard' && st.turn === AI) s = '电脑思考中…';
    else if (dealingNow()) s = '发牌中…';
    else s = '轮到你出牌';
    if (game.state.result && game.state.result.flags && game.state.result.flags.tianhu) {
      $('status').textContent = '天胡！结算马上弹出…';
      return;
    }
    $('status').textContent = s;
  }

  /* ------------------------------------------------------------ 操作按钮 */
  function renderActs() {
    if (dealAnim) { $('acts').innerHTML = ''; return; }   // 发牌动画期间不显示按钮
    const st0 = game.state;
    if (gameEnded) {                                      // 对局已结束：只给「查看战果」
      $('acts').innerHTML = '';
      const back = document.createElement('button');
      back.className = 'ghost';
      back.textContent = '查看战果';
      back.addEventListener('click', () => { showGameOver(); });
      $('acts').appendChild(back);
      const again = document.createElement('button');
      again.className = 'primary';
      again.textContent = '再来一局';
      again.addEventListener('click', () => {
        $('modal').hidden = true;
        resultShown = false;
        gameEnded = false;
        hideTilePreview();
        game.newGame();
        render();
        scheduleAI();
      });
      $('acts').appendChild(again);
      return;
    }
    if (st0 && st0.result && $('modal').hidden) {
      $('acts').innerHTML = '';
      const back = document.createElement('button');
      back.className = 'ghost';
      back.textContent = '查看结算';
      back.addEventListener('click', () => { showResult(st0.result, true); });
      $('acts').appendChild(back);
      const next = document.createElement('button');
      next.className = 'primary';
      next.textContent = game.over ? '查看战果' : '下一局';
      next.addEventListener('click', () => {
        if (game.over) { showGameOver(); return; }   // 打满局数：先弹「游戏结束」
        $('modal').hidden = true;
        nextRound();
      });
      $('acts').appendChild(next);
      return;
    }
    const st = game.state;
    const box = $('acts');
    box.innerHTML = '';
    if (st.result) return;
    const me = st.players[HUMAN];

    const btn = (label, cls, fn) => {
      const b = document.createElement('button');
      b.textContent = label;
      b.className = cls;
      b.addEventListener('click', () => { if (!busy) fn(); });
      box.appendChild(b);
      return b;
    };

    // 鸣牌（胡 > 杠 > 碰 > 吃 > 过）
    if (st.phase === 'claim' && st.claim && st.claim.player === HUMAN) {
      const o = st.claim.options;
      if (o.hu) btn('胡', 'hu', () => game.claim('hu'));
      if (o.kan) btn('杠', 'act', () => game.claim('kan'));
      if (o.pon) btn('碰', 'act', () => game.claim('pon'));
      if (o.chi && o.chi.length) {
        o.chi.forEach((pair) => {
          const all = pair.concat([st.claim.tile]).sort((a, b) => a - b);
          const label = '吃 ' + all.map(E.tileShort).join('');
          btn(label, 'act', () => game.claim('chi', pair));
        });
      }
      btn('过', 'pass', () => game.claim('pass'));
      return;
    }

    if (st.phase === 'discard' && st.turn === HUMAN) {
      if (st.selfWin) btn('胡（自摸）', 'hu', () => game.declareSelfWin(HUMAN));
      const kans = game.canSelfKan(HUMAN);
      kans.forEach((k) => {
        const label = (k.type === 'ankan' ? '暗杠 ' : '加杠 ') + E.tileLabel(k.tile);
        btn(label, 'act', () => game.selfKan(HUMAN, k.type, k.tile));
      });
      if (game.canRiichi(HUMAN)) {
        btn(riichiPick ? '取消听牌' : '听牌', 'act', () => {
          riichiPick = riichiPick ? null : buildRiichiPick();
          render();
        });
      }
    }
  }

  /* ------------------------------------------------------------ 结算弹窗 */
  function showResult(res, instant) {
    hideTilePreview();            // 结算时收起悬空的听牌窗
    if (res && res.__logged !== true) {
      res.__logged = true;
      addRecord(res);
    }
    hideToast();
    hideWinBanner();
    // 结算面板打开时，操作栏上的「查看结算 / 下一局」不该出现
    if ($('acts')) $('acts').innerHTML = '';
    const modal = $('modal');
    const box = (modal && typeof modal.querySelector === 'function')
      ? modal.querySelector('.modal-box') : null;
    if (box) box.classList.toggle('noanim', !!instant);   // 二次打开时不重播动画
    const st = game.state;
    const winName = res.type === 'draw' ? '流局' :
      (res.winner === HUMAN ? '你' : '电脑') + (res.tsumo ? ' 自摸' : ' 和牌');

    $('modalTitle').textContent = '本局结算';   // 谁胡的、赢多少放在内容区的抬头

    if (res.type === 'draw') {
      const maxR0 = (game.opts && game.opts.maxRounds) || 8;
      const streak = game.drawStreak || 0;
      const rows = [];
      if (streak > 0) {
        rows.push('<div class="totalrow mulrow"><span>连续流局 ' + streak + ' 局</span><span>×' +
          Math.pow(2, streak) + '</span></div>');
      }
      rows.push('<div class="totalrow"><span>进度</span><span>' + st.roundNo + '/' + maxR0 + '</span></div>');
      const below = rows.map((html, i) =>
        html.replace(/^<div class="([^"]*)"/, (m0, cls) =>
          '<div class="' + cls + ' rowwait" style="animation-delay:' + (320 + i * 130) + 'ms"')
      ).join('');
      $('modalBody').innerHTML =
        '<div class="reshead">' +
          '<div class="resleft rowwait" style="animation-delay:40ms">' +
            '<div class="reswho">流局</div>' +
            '<div class="restag">牌墙摸完 · 无人和牌</div>' +
          '</div>' +
          '<div class="resdelta wait draw" style="animation-delay:140ms">±0</div>' +
        '</div>' +
        below;
      $('modalFoot').innerHTML = '';
      // 终局：下面只留一个「返回」，回到当前牌桌
      if ((game.over || gameEnded) && instant) {{
        const back = document.createElement('button');
        back.className = 'primary';
        back.textContent = '返回';
        back.addEventListener('click', () => {{ modal.hidden = true; render(); }});
        $('modalFoot').appendChild(back);
        modal.hidden = false;
        return;
      }}
      const v = document.createElement('button');
      v.className = 'ghost';
      v.textContent = '查看牌桌';
      v.addEventListener('click', () => {{ modal.hidden = true; render(); }});
      $('modalFoot').appendChild(v);
      const b = document.createElement('button');
      b.className = 'primary';
      b.textContent = '下一局';
      b.addEventListener('click', () => {{ modal.hidden = true; nextRound(); }});
      $('modalFoot').appendChild(b);
      modal.hidden = false;
      return;
    }

    /* 出场节奏：先手牌弹入 -> 停一下 -> 番种逐条 -> 停一下 -> 下面逐行 */
    const HAND_DELAY = 60;         // 手牌开始
    const STEP = 300;              // 每条番种间隔（毫秒），越大越慢
    const GAP_AFTER_HAND = 620;    // 手牌弹完停顿
    const GAP_AFTER_FANS = 420;    // 番种出完停顿
    const ROW_STEP = 130;          // 下面每行的间隔

    // 同名番合并成一条（箭刻+1 箭刻+1 -> 箭刻+2）
    const merged = new Map();
    res.fans.forEach((f) => merged.set(f.name, (merged.get(f.name) || 0) + f.fan));
    const sortedFans = Array.from(merged, ([name, fan]) => ({ name, fan }))
      .sort((a, b) => b.fan - a.fan);
    const fanStart = HAND_DELAY + GAP_AFTER_HAND;
    const chips = sortedFans.map((f, i) =>
      '<span style="animation-delay:' + (fanStart + i * STEP) + 'ms">' + f.name + ' <b>' + fmtFan(f.fan) + '</b></span>'
    ).join('');
    const belowStart = fanStart + Math.max(sortedFans.length, 1) * STEP + GAP_AFTER_FANS;

    // 顶部：谁胡的 + 大大的分差
    const isHuman = res.winner === HUMAN;
    const myDeltaRaw = isHuman ? res.amount : -res.amount;   // 站在「你」的角度：输就显示负分
    const myDelta = fmtScore(myDeltaRaw);
    const wayText = res.tsumo ? '自摸' : '点炮';
    const topFan = sortedFans.length ? sortedFans[0].name : '无番';   // 只放最大的一个番
    const totalMul = res.multipliers.reduce((a, m) => a * m.factor, 1);

    const rows = [];
    rows.push('<div class="totalrow"><span>基本分</span><span>' + fmtScore(res.baseScore) + ' 分</span></div>');
    // 每条倍率单独一行，样式与「基本分」一致
    res.multipliers.forEach((m) => {
      rows.push('<div class="totalrow mulrow"><span>' + m.name + '</span><span>×' +
        (Math.round(m.factor * 100) / 100) + '</span></div>');
    });
    rows.push('<div class="totalrow totalfinal"><span>总分</span><span class="big">' +
      fmtScore(res.amount) + ' 分</span></div>');
    rows.push('<div class="totalrow"><span>当前分数</span><span>' +
      fmtScore(st.players[HUMAN].score) + ' 分</span></div>');
    rows.push('<div class="totalrow"><span>进度</span><span>' + st.roundNo + '/' +
      ((game.opts && game.opts.maxRounds) || 8) + '</span></div>');
    // 每一行都挂上 rowwait + 递增延迟（不管是 totalrow / mul / totalfinal / mulsum）
    const below = rows.map((html, i) =>
      html.replace(/^<div class="([^"]*)"/, (m0, cls) =>
        '<div class="' + cls + ' rowwait" style="animation-delay:' + (belowStart + i * ROW_STEP) + 'ms"')
    ).join('');

    const fanLine = sortedFans.map((f, i) =>
      '<span style="animation-delay:' + (fanStart + i * STEP) + 'ms">' + f.name + '<b>+' + fmtFan(f.fan) + '</b></span>'
    ).join('');

    // 分数放在最后弹
    const deltaDelay = belowStart + rows.length * ROW_STEP + 240;

    const body = $('modalBody');
    body.innerHTML =
      '<div class="reshead">' +
        '<div class="resleft rowwait" style="animation-delay:40ms">' +
          '<div class="reswho">' + (isHuman ? '你' : '电脑') + ' · ' + wayText + '胡</div>' +
          '<div class="restag">' + topFan + ' · ' + fmtFan(res.fan) + ' 番</div>' +
        '</div>' +
        '<div class="resdelta wait' + (myDeltaRaw > 0 ? ' plus' : ' minus') +
          '" style="animation-delay:' + deltaDelay + 'ms">' +
          (isFinite(myDeltaRaw)
            ? ((myDeltaRaw > 0 ? '+' : '-') + Math.abs(myDeltaRaw))
            : '∞') +
          (res.capped ? '<i class="capped">（封顶）</i>' : '') +
        '</div>' +
      '</div>' +
      '<div class="handview handwait" id="resHand" style="animation-delay:' + (HAND_DELAY + 120) + 'ms"></div>' +
      '<div class="fanline">' + (fanLine || '<span style="animation-delay:' + fanStart + 'ms">无番</span>') + '</div>' +
      '<div class="fantotal rowwait" style="animation-delay:' +
        (fanStart + Math.max(sortedFans.length, 1) * STEP + 120) + 'ms"><b>' +
        fmtFan(res.fan) + '</b> 番</div>' +
      below;

    const hv = $('resHand');
    // 把和牌的那一张抽出来，单独放到最右侧
    const rest = res.hand.slice();
    let winIdx = -1;
    if (res.winTile != null) {
      for (let i = rest.length - 1; i >= 0; i--) {
        if (rest[i] === res.winTile) { winIdx = i; break; }
      }
    }
    if (winIdx >= 0) rest.splice(winIdx, 1);

    rest.slice().sort((a, b) => b - a).forEach((t) => hv.appendChild(tileEl(t, 'tiny')));
    // 副露接在同一行（花牌不显示）；暗杠在结算里亮出来并标注「暗杠」
    (res.melds || []).forEach((m) => {
      if (m.kind === 'ankan') {
        // 暗杠：外侧两张亮出、中间两张背面，整体和吃碰一样
        const box = document.createElement('div');
        box.className = 'meld';
        const mkBack = () => {
          const b = document.createElement('div');
          b.className = 'back tiny-back';
          return b;
        };
        box.appendChild(tileEl(m.tiles[0], 'tiny'));
        box.appendChild(mkBack());
        box.appendChild(mkBack());
        box.appendChild(tileEl(m.tiles[0], 'tiny'));
        hv.appendChild(box);
      } else {
        hv.appendChild(meldEl(m, 'tiny'));
      }
    });
    if (winIdx >= 0) {
      const sep = document.createElement('span');
      sep.className = 'winsep';
      hv.appendChild(sep);
      hv.appendChild(tileEl(res.winTile, 'tiny win'));
    }

    $('modalFoot').innerHTML = '';
    // 终局：下面只留一个「返回」，回到当前牌桌
    if ((game.over || gameEnded) && instant) {{
      const back = document.createElement('button');
      back.className = 'primary';
      back.textContent = '返回';
      back.addEventListener('click', () => {{ modal.hidden = true; render(); }});
      $('modalFoot').appendChild(back);
      modal.hidden = false;
      return;
    }}
    const v = document.createElement('button');
    v.className = 'ghost';
    v.textContent = '查看牌桌';
    v.addEventListener('click', () => {{ modal.hidden = true; render(); }});
    $('modalFoot').appendChild(v);
    const b = document.createElement('button');
    b.className = 'primary';
    b.textContent = '下一局';
    b.addEventListener('click', () => {{ modal.hidden = true; nextRound(); }});
    $('modalFoot').appendChild(b);
    modal.hidden = false;

  }

  /* ------------------------------------------------- 对局结束弹窗 */
  function showGameOver() {
    const st = game.state;
    const me = st.players[HUMAN].score;
    const ai = st.players[AI].score;
    const start = (game.opts && game.opts.startScore) || 20000;
    const net = me - start;              // 自己的净得分（相对起始分）
    const diff = me - ai;                // 与电脑的分差
    const memeEnd = !!(st.result && st.result.infinite);
    const who = net > 0 ? (memeEnd ? '那说啥了给你了' : '你赢了！')
      : net < 0 ? '你输了' : '平局';
    const rounds = (game.opts && game.opts.maxRounds) || 8;
    const cls = net > 0 ? 'win' : net < 0 ? 'minus' : 'draw';
    const netText = net > 0 ? '+' + fmtScore(net) : (net < 0 ? fmtScore(net) : '0');
    const diffText = diff === 0 ? '±0' : (diff > 0 ? '+' : '') + fmtScore(diff);

    // 每局自己的得分（用实际对局记录）
    const hist = (game.history || []).slice();
    const roundRows = hist.map((h) => {
      const isDraw = h.type === 'draw';
      const delta = isDraw ? 0 : (h.winner === HUMAN ? (h.amount || 0) : -(h.amount || 0));
      const rcls = delta > 0 ? ' plus' : delta < 0 ? ' minus' : '';
      const txt = delta > 0 ? '+' + fmtScore(delta) : (delta < 0 ? fmtScore(delta) : '0');
      return '<div class="totalrow"><span>第 ' + h.round + ' 局</span>' +
        '<span class="' + rcls.trim() + '">' + txt + '</span></div>';
    }).join('');

    const modal = $('modal');
    if ($('modalTitle')) $('modalTitle').textContent = '游戏结束';
    $('modalBody').innerHTML =
      '<div class="reshead">' +
        '<div class="resleft">' +
          '<div class="reswho">' + who + '</div>' +
          '<div class="restag">共 ' + rounds + ' 局 · 最终比分</div>' +
        '</div>' +
        '<div class="resdelta ' + cls + '">' + netText + '</div>' +
      '</div>' +
      roundRows +
      '<div class="totalrow totalfinal"><span>净得分</span><span class="big ' + cls + '">' +
        netText + ' 分</span></div>';

    $('modalFoot').innerHTML = '';
    const v = document.createElement('button');
    v.className = 'ghost';
    v.textContent = '查看牌桌';
    v.addEventListener('click', () => { modal.hidden = true; render(); });
    $('modalFoot').appendChild(v);
    const b = document.createElement('button');
    b.className = 'primary';
    b.textContent = '再来一局';
    b.addEventListener('click', () => { modal.hidden = true; nextRound(); });
    $('modalFoot').appendChild(b);
    modal.hidden = false;
  }

  function nextRound() {
    gameEnded = false;
    hideTilePreview();            // 换局前收起悬空的听牌窗
    resultShown = false;
    resultPending = false;
    hideWinBanner();
    riichiPick = null;
    if (game.over) {
      game.newGame();
      gameEnded = false;
    } else {
      game.nextRound();
    }
    render();
    scheduleAI();
  }

  /* ------------------------------------------------------------ 规则面板 */
  function buildRules() {
    const groups = {};
    E.FAN_LIST.forEach((f) => { (groups[f.group] = groups[f.group] || []).push(f); });
    let html = '<h3>牌库</h3>' +
      '<p>万 1~9 + 字牌 东南西北中发白（每张 4 枚）+ 八张花（春夏秋冬梅兰竹菊）+ <b>4 张癞子</b>，共 <b>76 张</b>。</p>' +
      '<p><b>花牌</b>：摸到即亮出放进自己的花牌区，然后补摸一张，不占手牌；按张数计「花牌类」番。<br>' +
      '<b>癞子</b>：万能牌，可当任意一张牌用，不能碰杠；打出的癞子单独放进自己的癞子区。整手牌没用癞子时：<b>起胡番减半</b>，并且<b>最终点数 ×2</b>。</p>' +
      '<h3>基本规则</h3>' +
      '<p>两人对局，庄家 14 张、闲家 13 张；初始各 <b>20000 分</b>；<b>6 番起胡</b>，共 <b>4 局</b>' +
      '（默认配置，可在「设置」里调整）。' +
      '<br>可以吃、碰、杠、胡；癞子不能碰、杠；报听后手牌锁定（摸什么打什么）。</p>';
    html += '<h3>番数换算</h3><table><tr><th>番数</th><th>分值</th></tr>';
    let prev = 1;
    E.SCORE_TABLE.forEach((r) => {
      const lo = prev, hi = r.max;
      prev = r.max + 1;
      html += '<tr><td class="fan">' + (hi === Infinity ? lo + ' 番以上' : lo + ' ~ ' + hi + ' 番') +
        '</td><td class="desc">' + r.score + ' 分</td></tr>';
    });
    html += '</table>';
    Object.keys(groups).forEach((g) => {
      html += '<h3>' + g + '</h3><table>';
      groups[g].forEach((f) => {
        html += '<tr><td class="fan">' + f.name + ' ' + fmtFan(f.fan) + ' 番</td><td class="desc">' + f.desc + '</td></tr>';
      });
      html += '</table>';
    });
    html += '<h3>得分倍率</h3>' +
      '<p class="mulhead"><b>×2</b></p>' +
      '<ul class="mullist">' +
      '<li><b>连续流局</b>：每多一局翻一倍（×2 / ×4 / ×8…），直到有人胡牌才清零</li>' +
      '<li><b>癞子杠</b>：本局主动打出过癞子时，打出的人自己胡牌 ×2（2 张则 ×4）</li>' +
      '</ul>' +
      '<p class="mulhead"><b>÷2</b></p>' +
      '<ul class="mullist">' +
      '<li>胡的那张牌是自己曾经打出过的牌种</li>' +
      '<li>见逃后胡同一张</li>' +
      '<li>和牌时手上有 3~4 张癞子（胡进来的那张不算）</li>' +
      '<li>单吊癞子胡牌</li>' +
      '</ul>';
    $('rulesBody').innerHTML = html;
  }

  /* ------------------------------------------------------------ 事件绑定 */
  $('btnRules').addEventListener('click', () => { $('rulesModal').hidden = false; });
  $('rulesClose').addEventListener('click', () => { $('rulesModal').hidden = true; });
  $('rulesModal').addEventListener('click', (e) => { if (e.target.id === 'rulesModal') $('rulesModal').hidden = true; });
  $('btnNew').addEventListener('click', () => {
    $('modal').hidden = true;
    resultShown = false;
    gameEnded = false;
    game.newGame();
    render();
    scheduleAI();
  });
  if ($('btnEnd')) $('btnEnd').addEventListener('click', () => { endGameEarly(); });

  /* ------------------------------------------------------------ 对局设置 */
  const SET_KEY = 'mj2p.settings';
  function loadSettings() {
    let cfg = null;
    try { cfg = JSON.parse(localStorage.getItem(SET_KEY) || 'null'); } catch (e) { cfg = null; }
    if (cfg) {
      if (cfg.memeFans === false) E.setMemeEnabled(false);
      if (cfg.minFan) E.setMinFan(cfg.minFan);
      if (cfg.maxRounds) game.opts.maxRounds = cfg.maxRounds;
      if (cfg.startScore) game.opts.startScore = cfg.startScore;
      if (cfg.capScore != null) game.opts.capScore = cfg.capScore;
    }
  }
  function saveSettings(cfg) {
    try { localStorage.setItem(SET_KEY, JSON.stringify(cfg)); } catch (e) { /* ignore */ }
  }
  function openSettings() {
    // 在开始页（还没开局）打开时，按钮只是「应用」；对局中才是「应用并重开」
    const onMenu = !!(document.body && document.body.classList && document.body.classList.contains('menu-open'));
    if ($('setApply')) $('setApply').textContent = onMenu ? '应用' : '应用并重开';
    $('setMinFan').value = E.getMinFan();
    $('setRounds').value = String(game.opts.maxRounds || 8);
    $('setScore').value = game.opts.startScore;
    $('setCap').value = game.opts.capScore == null ? 30000 : game.opts.capScore;
    $('jokerSel').value = game.opts.jokerCount;
    $('testMode').checked = !!game.opts.testMode;
    $('setMeme').checked = E.getMemeEnabled() === true;
    $('setReveal').checked = game.opts.revealOnRiichi === true;
    $('peekMode').checked = !!game.opts.peekMode;
    $('setModal').hidden = false;
  }
  $('btnSet').addEventListener('click', openSettings);
  $('setClose').addEventListener('click', () => { $('setModal').hidden = true; });
  $('setModal').addEventListener('click', (e) => {
    if (e.target.id === 'setModal') $('setModal').hidden = true;
  });
  // 设置项改动即时生效（不用等「应用」）
  function liveMinFan() {
    const v = Math.max(1, Math.min(30, parseInt($('setMinFan').value, 10) || 6));
    E.setMinFan(v);
    saveSettings({ minFan: v, maxRounds: game.opts.maxRounds, startScore: game.opts.startScore,
      capScore: game.opts.capScore });
    render();
  }
  $('setMinFan').addEventListener('input', liveMinFan);
  $('setMinFan').addEventListener('change', liveMinFan);

  $('setRounds').addEventListener('change', () => {
    game.opts.maxRounds = parseInt($('setRounds').value, 10) === 4 ? 4 : 8;
    saveSettings({ minFan: E.getMinFan(), maxRounds: game.opts.maxRounds,
      startScore: game.opts.startScore, capScore: game.opts.capScore });
    render();
  });

  $('setCap').addEventListener('change', () => {
    const raw = parseInt($('setCap').value, 10);
    game.opts.capScore = Math.max(0, Math.min(1000000, isNaN(raw) ? 30000 : raw));
    saveSettings({ minFan: E.getMinFan(), maxRounds: game.opts.maxRounds,
      startScore: game.opts.startScore, capScore: game.opts.capScore });
  });

  $('setMeme').addEventListener('change', () => {
    E.setMemeEnabled($('setMeme').checked);
    saveSettings({ minFan: E.getMinFan(), maxRounds: game.opts.maxRounds,
      startScore: game.opts.startScore, capScore: game.opts.capScore,
      memeFans: $('setMeme').checked });
    render();
  });

  $('setReveal').addEventListener('change', () => {
    game.opts.revealOnRiichi = $('setReveal').checked;
    render();
  });

  $('setApply').addEventListener('click', () => {
    const minFan = Math.max(1, Math.min(30, parseInt($('setMinFan').value, 10) || 6));
    const rounds = parseInt($('setRounds').value, 10) === 4 ? 4 : 8;
    const score = Math.max(1000, Math.min(1000000, parseInt($('setScore').value, 10) || 20000));

    // 顶栏搬进来的几项
    game.opts.testMode = $('testMode').checked;
    game.opts.revealOnRiichi = $('setReveal').checked;
    game.opts.peekMode = $('peekMode').checked;
    const capRaw = parseInt($('setCap').value, 10);
    const cap = Math.max(0, Math.min(1000000, isNaN(capRaw) ? 30000 : capRaw));
    const JOKER_CHOICES = [0, 4, 8, 12, 16];
    const jokRaw = parseInt($('jokerSel').value, 10);
    const jok = JOKER_CHOICES.indexOf(jokRaw) >= 0 ? jokRaw : 4;
    game.opts.capScore = cap;
    game.opts.jokerCount = jok;
    try { localStorage.setItem('mj2p.jokerCount', String(jok)); } catch (e) { /* ignore */ }
    try { localStorage.setItem('mj2p.testMode', game.opts.testMode ? '1' : '0'); } catch (e) { /* ignore */ }
    try { localStorage.setItem('mj2p.peekMode', game.opts.peekMode ? '1' : '0'); } catch (e) { /* ignore */ }

    if ($('setMeme')) E.setMemeEnabled($('setMeme').checked);
    E.setMinFan(minFan);
    game.opts.maxRounds = rounds;
    game.opts.startScore = score;
    saveSettings({ minFan: minFan, maxRounds: rounds, startScore: score, capScore: cap });

    $('setModal').hidden = true;

    // 开始页里点「应用」：只保存设置，不开局（牌桌本来就没显示）
    if (document.body && document.body.classList && document.body.classList.contains('menu-open')) {
      game.scores = [score, score];
      game.opts.startScore = score;
      syncStartFoot();
      return;
    }

    $('modal').hidden = true;
    resultShown = false;
    riichiPick = null;
    game.scores = [score, score];        // 起始分数变了，重新开一场
    game.newGame();
    gameEnded = false;
    render();
    scheduleAI();
  });

  /* --------------------------------------------------- 牌墙告警（居中提示） */
  let wallWarned = { round: -1, ten: false, five: false };
  let wallToastEl = null;
  function toastWall(text, cls, life) {
    if (!document.body || !document.createElement) return;   // 无 DOM 环境（测试）直接跳过
    if (wallToastEl && wallToastEl.parentNode) wallToastEl.parentNode.removeChild(wallToastEl);
    const el = document.createElement('div');
    el.className = 'walltoast' + (cls ? ' ' + cls : '');
    el.textContent = text;
    document.body.appendChild(el);
    wallToastEl = el;
    const L = life || 2100;
    setTimeout(() => el.classList.add('out'), Math.max(200, L - 400));
    setTimeout(() => { if (el.parentNode) el.parentNode.removeChild(el); }, L);
  }
  let resultPending = false;    // 正在等胡牌横幅播完再弹结算
  let huToastRound = -1;        // 哪一局已经弹过「胡了」标识
  // 吃 / 碰 / 杠：副露变化时在那一侧弹横幅
  let meldSeen = [null, null];
  function meldSigOf(p) {
    return {
      count: p.melds.length,
      sig: p.melds.map((m) => m.kind + ':' + m.tiles.join(',')).join('|'),
    };
  }
  function checkMeldBanner(st) {
    if (!st || st.result) return;
    [0, 1].forEach((i) => {
      const cur = meldSigOf(st.players[i]);
      const prev = meldSeen[i];
      meldSeen[i] = cur;
      if (!prev) return;                       // 首次记录，不弹
      let text = null;
      if (cur.count > prev.count) {
        const m = st.players[i].melds[st.players[i].melds.length - 1];
        text = m.kind === 'chi' ? '吃！' : (m.kind === 'pon' ? '碰！' : '杠！');
      } else if (cur.count === prev.count && cur.sig !== prev.sig) {
        text = '杠！';                          // 加杠
      }
      if (text) showBanner(i === HUMAN, text, 'meld', 750);
    });
  }
  let riichiSeen = [false, false];
  function checkRiichiToast(st) {
    if (!st || st.result) return;
    [0, 1].forEach((i) => {
      const on = !!(st.players[i] && st.players[i].riichi);
      if (on && !riichiSeen[i]) {
        riichiSeen[i] = true;
        showBanner(i === HUMAN, '听！', 'ting');
      } else if (!on) {
        riichiSeen[i] = false;
      }
    });
  }
  let winBannerEl = null;
  function showBanner(isHuman, text, kind, life) {
    if (!document.body || !document.createElement) return;
    if (winBannerEl && winBannerEl.parentNode) winBannerEl.parentNode.removeChild(winBannerEl);
    const el = document.createElement('div');
    el.className = 'wintoast ' + (isHuman ? 'human' : 'ai') + (kind ? ' ' + kind : '');
    el.textContent = text;
    document.body.appendChild(el);
    winBannerEl = el;
    setTimeout(() => { if (el.parentNode) el.parentNode.removeChild(el); }, life || 1000);
  }
  function showWinBanner(isHuman, tsumo) {
    showBanner(isHuman, tsumo ? '自摸！' : '胡！');
  }
  function hideWinBanner() {
    if (winBannerEl && winBannerEl.parentNode) winBannerEl.parentNode.removeChild(winBannerEl);
    winBannerEl = null;
  }
  function hideToast() {
    if (wallToastEl && wallToastEl.parentNode) wallToastEl.parentNode.removeChild(wallToastEl);
    wallToastEl = null;
  }
  function checkWallWarn(st) {
    if (!st || st.result) return;
    if (wallWarned.round !== st.round) wallWarned = { round: st.round, ten: false, five: false };
    const n = st.wall.length;
    if (!wallWarned.ten && n <= 10 && n > 5) { wallWarned.ten = true; toastWall('牌墙只剩 ' + n + ' 张'); }
    else if (!wallWarned.five && n <= 5) { wallWarned.five = true; toastWall('牌墙只剩 ' + n + ' 张！'); }
  }

  /* ------------------------------------------------------------ 测试模式 */
  const TEST_KEY = 'mj2p.testMode';
  function syncTestUI() {
    const on = !!game.opts.testMode;
    const box = $('testMode');
    if (box) box.checked = on;
    const label = box && box.parentNode;
    if (label) label.classList.toggle('on', on);
  }
  // 测试模式：勾选只改界面状态，不立刻动牌桌；点「应用并重开」才生效
  $('testMode').addEventListener('change', (e) => {
    const on = !!e.target.checked;
    const label = e.target.parentNode;
    if (label) label.classList.toggle('on', on);
  });

  /* ------------------------------------------------------------ 透视（看对手手牌） */
  const PEEK_KEY = 'mj2p.peekMode';
  function syncPeekUI() {
    const box = $('peekMode');
    if (!box) return;
    box.checked = !!game.opts.peekMode;
    const label = box.parentNode;
    if (label) label.classList.toggle('on', !!game.opts.peekMode);
  }
  $('peekMode').addEventListener('change', (e) => {
    game.opts.peekMode = !!e.target.checked;      // 只改显示，不动牌局
    try { localStorage.setItem(PEEK_KEY, game.opts.peekMode ? '1' : '0'); } catch (err) { /* ignore */ }
    syncPeekUI();
    render();
  });

  /* ------------------------------------------------------------ 癞子张数 */
  const JOKER_KEY = 'mj2p.jokerCount';
  function readJokerPref() {
    try {
      const v = parseInt(localStorage.getItem(JOKER_KEY), 10);
      if (!isNaN(v)) return normJoker(v);
    } catch (e) { /* 无 localStorage 时忽略 */ }
    return game.opts.jokerCount;
  }
  function saveJokerPref(n) {
    try { localStorage.setItem(JOKER_KEY, String(n)); } catch (e) { /* ignore */ }
  }
  const JOKER_CHOICES = [0, 4, 8, 12, 16];
  function normJoker(n) {
    const v = n | 0;
    return JOKER_CHOICES.indexOf(v) >= 0 ? v : 4;
  }
  function applyJokerCount(n, restart) {
    const v = normJoker(n);
    $('jokerSel').value = v;
    game.opts.jokerCount = v;
    saveJokerPref(v);
    if (restart) {
      $('modal').hidden = true;
      resultShown = false;
      game.newGame();
      gameEnded = false;
      render();
      scheduleAI();
    }
  }

  // 癞子张数：下拉只是选择，不动牌桌；点「应用并重开」才真正生效
  $('jokerSel').addEventListener('change', (e) => {
    e.target.value = normJoker(parseInt(e.target.value, 10));
  });

  /* ------------------------------------------------------------ PWA 注册 */
  // 只有通过 http(s) 打开（而不是 file://）时才注册，file:// 下浏览器会直接忽略
  if (typeof navigator !== 'undefined' && navigator.serviceWorker &&
      typeof location !== 'undefined' && location.protocol.indexOf('http') === 0) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('sw.js').then((reg) => {
        // 有新版本就让它立刻接管，并在接管后刷新一次页面
        if (reg.waiting) reg.waiting.postMessage('skip-waiting');
        reg.addEventListener('updatefound', () => {
          const sw = reg.installing;
          if (!sw) return;
          sw.addEventListener('statechange', () => {
            if (sw.state === 'installed' && navigator.serviceWorker.controller) {
              sw.postMessage('skip-waiting');
            }
          });
        });
        // 顺手清理旧缓存（旧版 sw 缓存优先会一直喂旧页面）
        if (typeof caches !== 'undefined') {
          caches.keys().then((keys) => {
            keys.forEach((k) => {
              if (k !== 'mj2p-v4') caches.delete(k).catch(() => {});
            });
          }).catch(() => {});
        }
        try { reg.update(); } catch (e) { /* 忽略 */ }

        let reloaded = false;
        navigator.serviceWorker.addEventListener('controllerchange', () => {
          if (reloaded) return;
          reloaded = true;
          location.reload();
        });
      }).catch(() => { /* 忽略 */ });
    });
  }

  /* ------------------------------------------------------------ 牌谱记录 */
  const LOG_KEY = 'mj2p_records_v1';
  const LOG_MAX = 120;

  function readRecords() {
    try {
      const raw = localStorage.getItem(LOG_KEY);
      const arr = raw ? JSON.parse(raw) : [];
      return Array.isArray(arr) ? arr : [];
    } catch (e) { return []; }
  }

  function writeRecords(arr) {
    try { localStorage.setItem(LOG_KEY, JSON.stringify(arr.slice(-LOG_MAX))); } catch (e) {}
  }

  // 一局打完记一条（测试模式不记）
  function addRecord(res) {
    if (!res) return;
    if (game.opts && game.opts.testMode) return;
    const st = game.state;
    const winners = res.type === 'draw' ? 'draw' : (res.winner === HUMAN ? 'me' : 'ai');
    const rec = {
      t: Date.now(),
      gid: game.gameId || 0,          // 场次 id（提前结束对局时整场剔除）
      round: st.roundNo,
      who: winners,
      tsumo: !!res.tsumo,
      fan: res.type === 'draw' ? 0 : res.fan,
      amount: res.type === 'draw' ? 0 : res.amount,
      infinite: !!res.infinite,
      me: st.players[HUMAN].score,
      ai: st.players[AI].score,
      fans: res.type === 'draw' ? [] : (res.fans || []).map((f) => f.name),
    };
    const arr = readRecords();
    arr.push(rec);
    writeRecords(arr);
  }

  function fmtTime(ts) {
    const d = new Date(ts);
    const p2 = (n) => (n < 10 ? '0' + n : '' + n);
    return (d.getMonth() + 1) + '/' + d.getDate() + ' ' + p2(d.getHours()) + ':' + p2(d.getMinutes());
  }

  function buildLog() {
    const body = $('logBody');
    if (!body) return;
    const arr = readRecords().slice().reverse();
    if (!arr.length) {
      body.innerHTML = '<div class="logempty">还没有牌谱。<br />打一局（不是测试模式）之后就会记在这里。</div>';
      return;
    }
    const rows = arr.map((r) => {
      const who = r.who === 'draw' ? '流局' : (r.who === 'me' ? '你' : '电脑');
      const cls = r.who === 'draw' ? 'draw' : (r.who === 'me' ? 'me' : 'ai');
      const delta = r.amount ? (r.who === 'me' ? r.amount : -r.amount) : 0;
      const amt = r.who === 'draw' ? '±0' :
        ((r.who === 'me' ? '+' : '-') + (r.infinite ? '∞' : fmtScore(r.amount)));
      const amtCls = r.who === 'draw' ? '' : (r.who === 'me' ? ' up' : ' down');
      const fan = r.who === 'draw' ? '牌墙摸完' : (r.infinite ? '∞ 番' : r.fan + ' 番') +
        (r.tsumo ? ' · 自摸' : ' · 点和');
      return '<div class="logrow">' +
        '<span class="lround">' + fmtTime(r.t) + ' 第' + r.round + '局</span>' +
        '<span class="lwho ' + cls + '">' + who + '</span>' +
        '<span class="lfan">' + fan + '</span>' +
        '<span class="lamt' + amtCls + '">' + amt + '</span>' +
      '</div>';
    }).join('');
    body.innerHTML = '<div class="loglist">' + rows + '</div>';
  }

  function openLog() {
    buildLog();
    $('logModal').hidden = false;
  }

  /* ------------------------------------------------------------ 启动 */
  window.__mjgame = game;      // 便于调试 / 自动化测试
  window.__mjTile = tileEl;    // 牌面渲染，截图用
  window.__mjengineMinFan = () => E.getMinFan();
  window.__mjFlowerIntro = () => flowerIntro;      // 调试用

  /* ------------------------------------------------------------ 开始页 */
  function syncStartFoot() {
    const el = $('startFoot');
    if (!el) return;
    const st = game.opts;
    el.textContent = E.getMinFan() + ' 番起胡 · ' + (st.maxRounds || 8) + ' 局 · ' +
      (st.jokerCount == null ? 4 : st.jokerCount) + ' 张癞子 · 起始 ' + fmtScore(st.startScore || 20000) + ' 分';
  }

  function showStart() {
    syncStartFoot();
    if (document.body && document.body.classList) document.body.classList.add('menu-open');
    if ($('start')) $('start').hidden = false;
  }

  function startGame() {
    if (document.body && document.body.classList) document.body.classList.remove('menu-open');
    if ($('start')) $('start').hidden = true;
    game.newGame();
    gameEnded = false;
    render();
    scheduleAI();
  }

  loadSettings();
  buildRules();
  try {
    if (localStorage.getItem(TEST_KEY) === '1') game.opts.testMode = true;
    if (localStorage.getItem(PEEK_KEY) === '1') game.opts.peekMode = true;
  } catch (err) { /* ignore */ }
  syncTestUI();
  syncPeekUI();
  game.opts.jokerCount = readJokerPref();
  $('jokerSel').value = game.opts.jokerCount;
  /* ------------------------------------------------- 提前结束对局 */
  function endGameEarly() {
    const st = game.state;
    if (!st) return;
    clearTimeout(aiTimer);
    // 本场已记下的牌谱全部删掉（提前结束不进牌谱）
    try {
      const recs = readRecords().filter((r) => r.gid !== (game.gameId || 0));
      writeRecords(recs);
    } catch (e) { /* ignore */ }
    st.pendingDraw = null;
    game.over = true;
    gameEnded = true;
    hideTilePreview();
    if ($('modal')) $('modal').hidden = true;
    render();
    showGameOver();
  }

  // 开始页按钮
  if ($('btnStart')) $('btnStart').addEventListener('click', startGame);
  if ($('btnStartSet')) $('btnStartSet').addEventListener('click', () => openSettings());
  if ($('btnStartRules')) $('btnStartRules').addEventListener('click', () => {
    if ($('rulesModal')) $('rulesModal').hidden = false;
  });
  if ($('btnStartLog')) $('btnStartLog').addEventListener('click', openLog);
  if ($('logClose')) $('logClose').addEventListener('click', () => { $('logModal').hidden = true; });
  if ($('logModal')) $('logModal').addEventListener('click', (e) => {
    if (e.target.id === 'logModal') $('logModal').hidden = true;
  });
  if ($('logClear')) $('logClear').addEventListener('click', () => {
    writeRecords([]);
    buildLog();
  });

  // 先摆好一局（保证内部状态可用），再盖开始页；点「开始游戏」才真正发牌
  game.newGame();
  gameEnded = false;
  render();
  showStart();
})();
