@echo off
chcp 65001 >nul 2>nul
setlocal
cd /d "%~dp0"

set "GAME=%~dp0index.html"
set "GAME=%GAME:\=/%"
set "PROF=%~dp0profile"

set "BROWSER="
for %%P in (
  "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
  "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
  "%ProgramFiles%\Google\Chrome\Application\chrome.exe"
  "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
  "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"
) do (
  if exist %%P if not defined BROWSER set "BROWSER=%%~P"
)

if not defined BROWSER goto NOBROWSER

if not exist "%PROF%" mkdir "%PROF%"

start "" "%BROWSER%" --app="file:///%GAME%" --user-data-dir="%PROF%" --no-first-run --no-default-browser-check --window-size=1280,820 --window-position=60,40 --allow-file-access-from-files
exit /b 0

:NOBROWSER
echo.
echo   [ERROR] Microsoft Edge or Google Chrome not found.
echo   Install Edge, or double-click index.html directly.
echo.
pause
exit /b 1
